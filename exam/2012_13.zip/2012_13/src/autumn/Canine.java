package autumn;

public abstract class Canine extends Animal {

}
