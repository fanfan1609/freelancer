package semester_1;

public class Main {

	public static void main(String[] args) throws ServiceBackUpException, NoServiceRequestException {
		// TODO Auto-generated method stub
		ServiceRequest service = new ServiceRequest(2);
		
		service.addName("Cleaning");
		service.addName("Fragment");
		
		service.removeName("Test");
		
	}

}
