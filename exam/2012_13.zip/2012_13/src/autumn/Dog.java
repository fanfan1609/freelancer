package autumn;

public class Dog extends Canine implements DomesticPet {

	@Override
	public void Play() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Cuddle() {
		// TODO Auto-generated method stub

	}

	public void show(Dog dog){
		System.out.println("Dog object");
	}
}
