package semester;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class Employee {
	
	private String firstName;
	private String lastName;
	private int phoneNumber;
	private Date dateOfBirth;
	
	public static Comparator<Employee> ALPHABETICAL_ORDER = new Comparator<Employee>() {
	    public int compare(Employee e1, Employee e2) {
	        int res = String.CASE_INSENSITIVE_ORDER.compare(e1.getLastName(), e2.getLastName());
	        if (res == 0) {
	            res = e1.getFirstName().compareTo(e2.getFirstName());
	        }
	        return res;
	    }
	};
	
	public static Comparator<Employee> AGE_ORDER = new Comparator<Employee>() {
	    public int compare(Employee e1, Employee e2) {
	        return e1.getBirthday().after(e2.getBirthday()) ? -1 : 1;
	    }
	};
	
	
	public Employee(String fName,String lName,int phone, Date date ){
		this.firstName = fName;
		this.lastName  = lName;
		this.phoneNumber = phone;
		this.dateOfBirth = date;
	}
	
	public String getFirstName(){
		return this.firstName;
	}
	
	public String getLastName(){
		return this.lastName;
	}
	
	public Date getBirthday(){
		return this.dateOfBirth;
	}
	
}