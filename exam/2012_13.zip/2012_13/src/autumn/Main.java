package autumn;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PetArrayList<Animal> pets = new PetArrayList<Animal>();
		
		// Create new pets
		Dog dog = new Dog();
		Cat cat = new Cat();
		Tiger tiger = new Tiger();
		Wolf wolf = new Wolf();
		
		System.out.println("Add cat into array :" + pets.add(cat));
		System.out.println("Add dog into array :" + pets.add(dog));
		System.out.println("Add tiger into array :" + pets.add(tiger));
		System.out.println("Add wolf into array :" + pets.add(wolf));
		
	}

}
