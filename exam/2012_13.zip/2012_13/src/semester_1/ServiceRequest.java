package semester_1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ServiceRequest {
	
	private String[] name;
	private int total;
	
	public ServiceRequest(int size){
		this.name = new String[size];
		total = 0;
	}
	
	public void addName(String name) throws ServiceBackUpException {
		try{
			if( this.total > this.name.length ){
				throw new ServiceBackUpException("Reach at limit of request");
			}
			this.name[this.total] = name;
			
		}catch(ServiceBackUpException sbex){
			System.out.println(sbex.getMessage());
		}
	}
	
	public String getName(int i){
		return this.name[i];
	}
	
	public void removeName(String name) throws NoServiceRequestException {
		try{
			List<String> array = new ArrayList<String>(Arrays.asList(this.name));
			if( array.contains(name) ){
				array.removeAll(Arrays.asList(name));
				this.name = array.toArray(this.name);
			} else {
				throw new NoServiceRequestException("No request with name :" + name);
			}
		}catch(NoServiceRequestException nsrex){
			System.out.println(nsrex.getMessage());
		}
	}
	
	public int getTotal(){
		return this.total;
	}
}
