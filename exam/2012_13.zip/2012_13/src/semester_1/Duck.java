package semester_1;

import java.util.UUID;

public class Duck implements Flyable{
	
	private String ID;
	private String name;
	private int age;
	
	public Duck(String name, int age){
		this.ID = UUID.randomUUID().toString();
		this.name = name;
		this.age = age;
	}
	
	public String getName(){
		return this.name;
	}
	
	public int getAge(){
		return this.age;
	}
	
	public String getID(){
		return this.ID;
	}
	
	
	public void fly(){
		
	}
}
