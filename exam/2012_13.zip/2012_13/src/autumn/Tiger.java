package autumn;

public class Tiger extends Feline {

}
