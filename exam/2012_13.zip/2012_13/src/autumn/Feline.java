package autumn;

public abstract class Feline extends Animal {

}
