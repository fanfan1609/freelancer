package autumn;

public interface DomesticPet {
	public void Play();
	public void Cuddle();
}
