package autumn;

public class Cat extends Feline implements DomesticPet {

	@Override
	public void Play() {
		// TODO Auto-generated method stub
	}

	@Override
	public void Cuddle() {
		// TODO Auto-generated method stub

	}
	
	public void show(Cat cat){
		System.out.println("Cat object");
	}

}
