package semester_1;

public class ServiceBackUpException extends Exception {
	
	public ServiceBackUpException(){
		super();
	}
	
	public ServiceBackUpException(String message) {
		super(message);
	}
	
	public ServiceBackUpException(String message, Throwable cause){
		super(message,cause);
	}
	
	public ServiceBackUpException(Throwable cause){
		super(cause);
	}
}
