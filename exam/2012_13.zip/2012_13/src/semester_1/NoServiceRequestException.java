package semester_1;

public class NoServiceRequestException extends Exception {

	public NoServiceRequestException(){
		super();
	}
	
	public NoServiceRequestException(String message) {
		super(message);
	}
	
	public NoServiceRequestException(String message, Throwable cause){
		super(message,cause);
	}
	
	public NoServiceRequestException(Throwable cause){
		super(cause);
	}
}
