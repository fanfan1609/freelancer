package autumn_2010_11;

import java.util.Arrays;

public class AddressBook {
	public static final int DEFAUL_SIZE = 25;
	public static final int NOT_FOUND 	= -1;
	private Person[] people;
	private int count;
	
	public AddressBook()
	{
		count = 0;
		people = new Person[DEFAUL_SIZE];
	}
	
	public AddressBook(int c)
	{
		count = 0;
		if( c <= 0 ) {
			people = new Person[DEFAUL_SIZE];
		} else {
			people = new Person[c];
		}
	}
	
	public void add(Person person)
	{
		if( count > (people.length - 1) ) {
			this.enlarge();
		}
		people[count] = person;
		count++;
	}
	
	public Person search(String name)
	{
		int index;
		index = this.findIndex(name);
		if( index == NOT_FOUND) {
			return null;
		} else {
			return people[index];
		}
	}
	
	public boolean delete(String name)
	{
		int index;
		index = this.findIndex(name);
		if( index == NOT_FOUND ){
			return false;
		} else {
			people[index] = null;
			return true;
		}
	}
	
	public String toString()
	{
		String output = "";
		output += "Address book : \n";
		for(Person curPerson: people ){
			output += "Name :" + curPerson.getName() + ", age :" + curPerson.getAge() + "\n";
		}
		
		return output;
	}
	
	public void print()
	{
		System.out.println(this.toString());
	}
	
	public void enlarge()
	{
		int curLength = people.length;
		int newLength = (int) (curLength*1.5);
		// Enlarge size to 150% old size
		people = Arrays.copyOf(people, newLength);
	}
	
	public int findIndex(String name)
	{
		int index = NOT_FOUND;
		for(int i=0; i< people.length;i++)
		{
			if( people[i].getName() == name ){
				index = i;
				break;
			}
		}
		return index;
	}
	
	public double getAvarageAge()
	{
		int totalAge = 0;
		for(Person curP : people){
			totalAge += curP.getAge();
		}
		if( people.length == 0 ) {
			return 0;
		} else {
			return totalAge / people.length ;
		}
	}
	
	public Person findYoungestPerson()
	{
		Person youngestPerson;
		if( people.length == 0) {
			return null;
		} else {
			youngestPerson = people[0];
			for(Person curPerson : people){
				if( curPerson.getAge() < youngestPerson.getAge() ){
					youngestPerson = curPerson;
				}
			}
			return youngestPerson;
		}
	}
	
	public Person findOldestPerson()
	{
		Person oldestPerson;
		if( people.length == 0) {
			return null;
		} else {
			oldestPerson = people[0];
			for(Person curPerson : people){
				if( curPerson.getAge() > oldestPerson.getAge() ){
					oldestPerson = curPerson;
				}
			}
			return oldestPerson;
		}
	}
	
	
}
