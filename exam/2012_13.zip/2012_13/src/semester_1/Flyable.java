package semester_1;

public interface Flyable {
	void fly();
}
