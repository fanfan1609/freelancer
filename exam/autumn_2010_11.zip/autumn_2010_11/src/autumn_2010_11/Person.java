package autumn_2010_11;

public class Person {
	private String name;
	private int age;
	
	public Person(String n, int a)
	{
		name = n; age = a;
	}
	
	public void setName(String n)
	{
		name = n;
	}
	
	public void setAge(int a)
	{
		age = a;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getAge()
	{
		return age;
	}
	
	public String toString()
	{
		return "Person detail : \n" + "Name: " + name +"\n" + "Age:" + age;
	}
	
	public void printDetails()
	{
		System.out.println( this.toString() );
	}
}
