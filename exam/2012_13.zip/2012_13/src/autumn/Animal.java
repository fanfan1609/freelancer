package autumn;

public abstract class Animal {
	
}
