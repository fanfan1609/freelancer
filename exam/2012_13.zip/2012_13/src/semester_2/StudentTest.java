package semester_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> studentList = new ArrayList<Student>();
		
		Student s1 = new Student("Mary");studentList.add(s1);
		Student s2 = new Student("Annie");studentList.add(s2);
		Student s3 = new Student("Peter");studentList.add(s3);
		Student s4 = new Student("Boob");studentList.add(s4);
		Student s5 = new Student("David");studentList.add(s5);
		Student s6 = new Student("Travis");studentList.add(s6);
		Student s7 = new Student("Nugeg");studentList.add(s7);
		
		Collections.sort(studentList, new Comparator<Student>() {
			@Override
			public int compare(Student s1, Student s2) {
				// TODO Auto-generated method stub
				return s1.getName().compareTo(s2.getName());
			}
		});
		
		System.out.println("Student list after sorting :");
		for(Student s : studentList){
			System.out.println(s.getName());
		}
	}

}
