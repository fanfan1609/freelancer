package semester_2;

public class BookClubTest {

	public static void main(String[] args) throws ClubFullException {
		// TODO Auto-generated method stub
		BookClub bookClub = new BookClub();
		
		// Create members
		Member m1 = new Member("David"); 
		m1.setAddress("Manchester");
		bookClub.join(m1);
		Member m2 = new Member("Peter");
		m2.setAddress("New York");
		bookClub.join(m2);

		bookClub.print();
	}

}
