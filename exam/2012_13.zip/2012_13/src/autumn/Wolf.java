package autumn;

public class Wolf extends Canine {

}
