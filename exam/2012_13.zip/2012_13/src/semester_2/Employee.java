package semester_2;

import java.util.concurrent.atomic.AtomicInteger;

public class Employee implements Comparable<Employee> {

	private static final AtomicInteger count = new AtomicInteger(0);
	private int Id;
	private String name;
	private int salary;
	
	public Employee(String name, int salary) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.salary = salary < 0 ? 0 :salary;
		this.Id = count.incrementAndGet();
	}
	
	@Override
	public int compareTo(Employee e) {
		// TODO Auto-generated method stub
		return Integer.compare(this.salary, e.salary);
	}
	
	public String getName(){
		return this.name;
	}

}
