
<script type="text/javascript">
(function() {
  var otto_script = document.createElement("script"); otto_script.type = "text/javascript";
  var http = (document.location.protocol == "https:" ? "https://" : "http://");
  otto_script.src = http + "sonician.info/otto/modules/tracker/pixel.js?t=" + new Date().getTime();
  document.getElementsByTagName("head")[0].appendChild(otto_script);
})();
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-8004803-4', 'auto');
  ga('send', 'pageview');

</script>

  