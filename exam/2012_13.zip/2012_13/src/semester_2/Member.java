package semester_2;

public class Member {

	private String name;
	private String address;
	
	public Member(String name){
		this.name = name;
		this.address = "";
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setAddress(String address){
		this.address = address;
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getAddress(){
		return this.address;
	}
	
	public String toString(){
		return this.name+ " with address " + this.address;
	}
	
	public void print(){
		System.out.println(this.toString());
	}
}
