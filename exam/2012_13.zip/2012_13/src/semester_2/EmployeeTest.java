package semester_2;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create employee
		Employee e1 = new Employee("David", 12356);
		Employee e2 = new Employee("Peter", 3431);
		
		int compare = e1.compareTo(e2);
		if( compare == 0 ){
			System.out.println(e1.getName()+" Salary is equal to " +e2.getName());
		} else if( compare > 0) {
			System.out.println(e1.getName()+" Salary is greater than " +e2.getName());
		} else {
			System.out.println(e1.getName()+" Salary is not greater than " +e2.getName());
		}
	}

}
