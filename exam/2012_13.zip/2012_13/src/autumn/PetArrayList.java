package autumn;

import java.util.ArrayList;

public class PetArrayList<Animal> extends ArrayList<Animal> {
	public boolean add(Animal pet){
		if( pet instanceof Dog || pet instanceof Cat ) return  super.add(pet);
		return false;
	}
}
