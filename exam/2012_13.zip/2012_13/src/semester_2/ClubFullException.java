package semester_2;

public class ClubFullException extends Exception {
	public ClubFullException(){
		super();
	}
	
	public ClubFullException(String message) {
		super(message);
	}
	
	public ClubFullException(String message, Throwable cause){
		super(message,cause);
	}
	
	public ClubFullException(Throwable cause){
		super(cause);
	}
}
