package autumn_2010_11;

public class Main {

	public static void main(String[] args) {
		// Create adress book
		AddressBook adBook = new AddressBook(5);
		
		// Create 5 person
		Person person1 = new Person("Dat", 26);
		Person person2 = new Person("Graye", 20);
		Person person3 = new Person("Peter", 10);
		Person person4 = new Person("Onie", 8);
		Person person5 = new Person("David", 56);
		
		// Add person into address book
		adBook.add(person1);
		adBook.add(person2);
		adBook.add(person3);
		adBook.add(person4);
		adBook.add(person5);
		
		// Calculating the average age of the people
		System.out.println("The averate age of people :" + adBook.getAvarageAge());
		System.out.println("The youngest person is " + adBook.findYoungestPerson().getName());
		System.out.println("The oldest person is " + adBook.findOldestPerson().getName());
	}

}
