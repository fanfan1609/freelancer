package semester2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;

public class NameTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Name> nameList = new ArrayList<Name>();
		
		Calendar c1 = new GregorianCalendar(1999, 5, 16);
		Name n1 = new Name("David", "Ginola", 121234, c1.getTime());
		nameList.add(n1);
		
		Calendar c2 = new GregorianCalendar(2009, 4, 6);
		Name n2 = new Name("Patrick", "Gunte", 4323412, c2.getTime());
		nameList.add(n2);
		
		Calendar c3 = new GregorianCalendar(2012, 3, 7);
		Name n3 = new Name("Travis", "Ginola", 121234, c3.getTime());
		nameList.add(n3);
		
		Calendar c4 = new GregorianCalendar(2007, 10, 8);
		Name n4 = new Name("David", "Suaez", 121234, c4.getTime());
		nameList.add(n4);
		
		Collections.sort(nameList,Name.ALPHABETICAL_ORDER);
		System.out.println("List name after sorting by name :");
		for(Name n : nameList){
			System.out.println(n.getFirstName() + " " + n.getLastName());
		}
		System.out.println("==========================================");
		
		Collections.sort(nameList,Name.HIRE_ORDER);
		System.out.println("List name after sorting by hire date :");
		for(Name n : nameList){
			System.out.println(n.getFirstName() + " " + n.getLastName() + " is hire from " + n.getHireDate().toString());
		}
	}

}
