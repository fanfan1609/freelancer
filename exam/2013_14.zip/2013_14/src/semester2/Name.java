package semester2;

import java.util.Comparator;
import java.util.Date;


public class Name {
	
	private String firstName;
	private String lastName;
	private int phoneNumber;
	private Date hireDate;
	
	public static Comparator<Name> ALPHABETICAL_ORDER = new Comparator<Name>() {
	    public int compare(Name e1, Name e2) {
	        int res = String.CASE_INSENSITIVE_ORDER.compare(e1.getLastName(), e2.getLastName());
	        if (res == 0) {
	            res = e1.getFirstName().compareTo(e2.getFirstName());
	        }
	        return res;
	    }
	};
	
	public static Comparator<Name> HIRE_ORDER = new Comparator<Name>() {
	    public int compare(Name e1, Name e2) {
	        return e1.getHireDate().after(e2.getHireDate()) ? 1 : -1;
	    }
	};
	
	public Name(String firstName,String lastName,int phone, Date date){
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phone;
		this.hireDate = date;
	}
	
	public String getFirstName(){
		return this.firstName;
	}
	
	public String getLastName(){
		return this.lastName;
	}
	
	public Date getHireDate(){
		return this.hireDate;
	}
}
