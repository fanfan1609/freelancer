package semester;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> employees = new ArrayList<Employee>();
		
		// Create 4 employee
		Calendar t1 = new GregorianCalendar(1987, 9, 16);
		Employee e1 = new Employee("Vo", "Dat", 12121, t1.getTime() );
		Calendar t2 = new GregorianCalendar(1988, 2, 6);
		Employee e2 = new Employee("David", "Grey", 11122121, t2.getTime() );
		Calendar t3 = new GregorianCalendar(1987, 5, 7);
		Employee e3 = new Employee("Uames", "Black", 1221121, t3.getTime() );
		Calendar t4 = new GregorianCalendar(1997, 2, 18);
		Employee e4 = new Employee("Travis", "Black", 3212121, t4.getTime() );
		
		// Add to list
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		
		Collections.sort(employees,Employee.ALPHABETICAL_ORDER);
		
		System.out.println("Sort by name");
		for(Employee e : employees){
			System.out.println("Employee name :" + e.getFirstName() + " " + e.getLastName() + " " + e.getBirthday().toString());
		}
		
		Collections.sort(employees,Employee.AGE_ORDER);
		System.out.println("Sort by age");
		for(Employee e : employees){
			System.out.println("Employee name :" + e.getFirstName() + " " + e.getLastName() + " " + e.getBirthday().toString());
		}
	}

}
