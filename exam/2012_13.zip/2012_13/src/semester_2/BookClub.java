package semester_2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookClub {
	
	private Member[] membersList;
	private int totalMembers;
	public static final int MEMBERSHIP_NO = 10;
	
	public BookClub(){
		this.totalMembers = 0;
		this.membersList  = new Member[MEMBERSHIP_NO];
	}
	
	public boolean join(Member m) throws ClubFullException {
		try{
			if( this.isFull() ){
				throw new ClubFullException("Book club is full of member");
			}
			this.membersList[totalMembers] = m;
			this.totalMembers++;
			return true;
		} catch(ClubFullException cfex){
			System.out.println(cfex.getMessage());
			return false;
		}
	}
	
	public Member[] getMembersList(){
		return this.membersList;
	}
	
	public int getTotalMembers(){
		return this.totalMembers;
	}
	
	public boolean deleteMember(Member m){
		List<Member> list = new ArrayList<Member>(Arrays.asList(this.membersList));
		if( list.contains(m)){
			boolean is_delete = list.removeAll(Arrays.asList(m));
			this.membersList = list.toArray(this.membersList);
			return is_delete;
		}
		return false;
	}
	
	public boolean isFull(){
		return this.totalMembers == this.membersList.length;
	}
	
	public boolean isEmpty(){
		return this.totalMembers == 0;
	}
	
	public String toString(){
		String output = "";
		output += "Member in Bookclub \n";
		for(int i=0;i < this.totalMembers;i++){
			output += this.membersList[i].toString() +"\n";
		}
		return output;
	}
	
	public void print(){
		System.out.println(this.toString());
	}
}
